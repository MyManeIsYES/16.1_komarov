package com.bignerdranch.android.pr16

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class EditAlarmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_alarm)
    }
}